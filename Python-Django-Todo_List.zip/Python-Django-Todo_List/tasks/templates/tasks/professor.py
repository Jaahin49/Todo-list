for _ in range(input()):
    n,k=map(int, input().split())
    a=map(int, input().split())
    count=0


    for i in a:
        if i<=0:
            count=count+1


    if count<k:
        print "YES"

    else:
        print "NO"






